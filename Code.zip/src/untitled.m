lasReader = lasFileReader('D:\data\tree6.las');
ptCloud = readPointCloud(lasReader);
P = ptCloud.Location;
P = P-mean(P);
QSM = treeqsm(P, inputs);
Pass = filtering(P0, inputs);
P = P0(Pass,:);
plot_spreads(treedata, 1, 1, 1)